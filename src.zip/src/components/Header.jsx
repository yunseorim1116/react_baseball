import React from "react";
const Headers = () => {
  return <h1>숫자야구게임</h1>;
};

export default Headers;
