import { useState, useEffect } from "react";

const Ball = ({ value, comNumber }) => {
  //   const valueArr = [...value];
  //   const [obj, setObj] = useState({
  //     strike: 0,
  //     ball: 0,
  //     out: 0,
  //   });
  //   console.log(value, comNumber);

  useEffect(() => {
    console.log("aaaaaaa");
  }, []);
  //   useEffect(() => {
  //     comNumber.forEach((number, idx) => {
  //       if (number == Number(valueArr[idx])) obj.strike++;
  //       else if (valueArr.includes(number)) obj.ball++;
  //       else obj.out++;
  //     });
  //   }, []);
  return (
    <div>
      {/* {valueArr.map((ball) => {
        return <span>{ball}</span>;
      })}

      <div>{obj.strike} 스트라이크</div>
      <div>{obj.ball} 볼</div>
      <div>{obj.out} 아웃</div> */}
    </div>
  );
};

export default Ball;
